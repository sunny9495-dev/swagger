from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
from selenium.webdriver.support.select import Select
from selenium.webdriver import ActionChains
import random
import time
import os


class Predefined():
    def __init__(self, driver):
        self.driver = driver
    def navigate(self, url):
        try:
            self.driver.get(url)
        except:
            return False
    def findelement(self, xpath):
        element = None
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            if element != None:
                return element
        except:
            return False
    def fileexist(self, file):
        element = None
        try:
           element = os.path.isfile(file)
           return element
        except:
            return False
    def waitforelement(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.presence_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def waitforelementdisplay(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def waitforelementenabled(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.element_to_be_clickable((By.XPATH, xpath)))
        except:
            return False
    def waitforelementdisappear(self, xpath, time):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.invisibility_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def element_exist(self, xpath):
        element = None
        try:
            element = len(self.driver.find_elements(By.XPATH, xpath))
            if element != 0:
                return True
        except:
            return False
    def element_display(self, xpath):
        try:
            self.driver.find_element(By.XPATH, xpath).is_displayed()
            return True
        except:
            return False
    def element_enabled(self, xpath):
        try:
            self.driver.find_element(By.XPATH, xpath).is_enabled()
            return True
        except:
            return False
    def doclick(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.click()
        except:
            return False
    def Enter(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.send_keys(Keys.ENTER)
        except:
            return False
    def typeinput(self, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.send_keys(input)
        except:
            return False
    def typeinput2(self, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.clear()
                element.send_keys(input)
        except:
            return False
    def screenshot(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1,100)
            file = f".\\{rand}.png"
            element.screenshot(file)
        except:
            return False
    def dropdownselect(self, xpath, value, type):
        element = None
        try:
            element = Select(self.findelement(xpath))
            if type == 'index':
                element.select_by_index(value)
            elif type == 'value':
                element.select_by_value(value)
            elif type == 'text':
                element.select_by_visible_text(value)
        except:
            return False
    def type_human_delay(self, xpath, input, minspeed, maxspeed):
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            for char in str(input):
                element.send_keys(char)
                time.sleep(random.uniform(minspeed, maxspeed))
        except:
            return False
    def alert_confirm(self):
        element = None
        try:
            element = self.driver.switch_to.alert.accept()
        except:
            return False
    def alert_dismiss(self):
        element = None
        try:
            element = self.driver.switch_to.alert.dismiss()
        except:
            return False
    def move_mouse(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
        except:
            return False
    def move_mouseaxis(self, xpath, xaxis, yaxis):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.move_to_element_with_offset(element, xaxis, yaxis).perform()
        except:
            return False
    def mouse_right_click(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.context_click(element).perform()
        except:
            return False
    def move_mouse_click(self, movexpath, clickxpath):
        element = None
        try:
            element = self.findelement(movexpath)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
            element = self.findelement(clickxpath)
            self.waitforelementdisplay(element, 10)
            action.move_to_element(element).click().perform()
        except:
            return False
    def ScrapeAttribute(self, xpath, type):
        element = None
        try:
            element = self.findelement(xpath).get_attribute(type)
        except:
            return False
        return element
    def elementcount(self, xpath):
        element = None
        try:
            element = len(self.driver.find_elements(By.XPATH, xpath))
        except:
            return False
        return element
    def switch_frame(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            self.driver.switch_to.frame(element)
        except:
            return False
    def clearText(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.clear()
        except:
            return False
    def selectalldelete(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            element.send_keys(Keys.CONTROL, 'a')
            element.send_keys(Keys.BACKSPACE)
        except:
            return False
    def switch_default(self):
        try:
            self.driver.switch_to.default_content()
        except:
            return False
    def scroll_to_element(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
        except:
            return False
    def ChangeAttribute(self, xpath, type, value):

        element = None
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            self.driver.execute_script(f"arguments[0].{type} = arguments[1]", element, value)
        except:
            return False