from flask import Flask, jsonify, request
from flask_jwt import JWT, jwt_required, current_identity, JWTError
from werkzeug.security import safe_str_cmp
from flasgger import Swagger
from seleniumwire import webdriver
from selenium.webdriver.chrome.options import Options
import os
import time
from utilities.core import Predefined
Description = """<p><iframe src="https://www.youtube.com/embed/-grLLLTza6k" frameborder="0" allowfullscreen=""></iframe></p><p><img src="https://images-na.ssl-images-amazon.com/images/I/71Zxjh0AdpL.png" style="width:100%;max-width:450px;clear:both;"></p><p></p><h2>10 Undeniable Reasons People Hate cheats</h2><p></p><p><a href="http://google.com">google</a>If you are questioning concerning utilizing a video game rip off to bump your online, computer system or computer game playing there are great deals of resources available to you. When you are very first beginning to play a game, particularly an on the internet game, you may be annoyed by your lack of skills as well as experience. You could be matched against a lot more seasoned players that benefit from you lack of expertise and abilities to beat you. A video game cheat program could also out the playing field. On the net you can download and install video game cheat software which will certainly offer you the rip off codes and other information that you will have to make you competitive with the most effective gamers.</p><p>It takes a great deal of time and patience to learn most of the on-line video games and also computer game on the market today. The majority of people do not have the time or persistence to do that, but they enjoy playing. When you play on the internet you will certainly be matched versus gamers that have accessibility to the video game cheat codes and software application currently. Give yourself that advantage by obtaining the codes and also software program on your own.</p><p>It is very easy to find a rip off program for nearly any game. You merely key in "game cheat" on your online search engine and "voila" an entire list of websites will turn up. Numerous of these websites supply cost-free trials of the software program so that you could attempt it out before you acquire it. Individuals you are betting will not have any indicator that you are making use of game rip off software application. Not just do these on the internet business supply game cheat codes for online video games but additionally games for systems like PS 2, X-Box, and the Video game Cube. The lists as well as codes are regularly being updated as brand-new video games and variations of video games appear.</p><p>A great deal of the on-line game cheat software program is interactive. You simply put it on before you start to play and also it will certainly tell you concerning upcoming chances as well as challenges as well as evaluating your challenger's relocate to tell you how to counter them. You could discover covert treasures, powers, as well as residential or commercial properties. If you like you can even most likely to various cheat code websites to try various software to understand which one you like the most effective.</p><p>No person prefers to lose. It is simply a video game, yet winning is still the things. Make on your own equivalent to your opponents and make the most of all the devices that are offered to you. As you improve you can count on them much less as well as on your own skills a lot more. It will get you going.<a href="http://yahoo.com">yahoo</a></p><p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13007070.354009148!2d-104.65387033028972!3d37.25828124582162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sus!4v1509017967634" frameborder="0" allowfullscreen=""></iframe></p>"""
Title = '''A Good Title for My Blog'''


curr_dir = os.getcwd()
driver_path = fr'{curr_dir}/utilities/drivers/chromedriver.exe'
browser_path = fr'{curr_dir}/utilities/drivers/browser/chrome.exe'

class User(object):
    def __init__(self, user_id, username, password):
        self.id = user_id
        self.username = username
        self.password = password

    def __str__(self):
        return "User(id='%s')" % self.id


users = [
    User(1, 'guest', 'secret'),
]

username_table = {u.username: u for u in users}
userid_table = {u.id: u for u in users}


def authenticate(username, password):
    user = username_table.get(username, None)
    if user and safe_str_cmp(user.password.encode('utf-8'), password.encode('utf-8')):
        return user


def identity(payload):
    user_id = payload['identity']
    return userid_table.get(user_id, None)


app = Flask(__name__)
app.debug = True
app.config["SECRET_KEY"] = "super-secret"
# app.config["SWAGGER"] = {
#     "title": "Swagger JWT Authentiation",
#     "uiversion": 3,
# }
app.config['JWT_AUTH_URL_RULE'] = '/api/auth'
app.config['JWT_AUTH_HEADER_NAME'] = 'Authorization'

swag = Swagger(app,
    template={
        "info": {
            "title": "Swagger JWT Authentication DEMO",
            "version": "1.0",
        },
        "consumes": [
            "application/x-www-form-urlencoded",
        ],
        "produces": [
            "application/json",
        ],
    },
)


def jwt_request_handler():
    auth_header_name = app.config['JWT_AUTH_HEADER_NAME']
    auth_header_value = request.headers.get(auth_header_name, None)
    if auth_header_value is not None:
      auth_header_value = auth_header_value.replace("Bearer", "jwt")
    auth_header_prefix = app.config['JWT_AUTH_HEADER_PREFIX']
    print(auth_header_value)
    print(auth_header_prefix)

    if not auth_header_value:
        return

    parts = auth_header_value.split()

    if parts[0].lower() != auth_header_prefix.lower():
        raise JWTError('Invalid JWT header', 'Unsupported authorization type')
    elif len(parts) == 1:
        raise JWTError('Invalid JWT header', 'Token missing')
    elif len(parts) > 2:
        raise JWTError('Invalid JWT header', 'Token contains spaces')

    return parts[1]


jwt = JWT(app, authenticate, identity)
jwt.request_handler(jwt_request_handler)


@app.route("/login", methods=["POST"])
def login():
    """
    User authenticate method.
    ---
    description: Authenticate user with supplied credentials.
    parameters:
      - name: username
        in: formData
        type: string
        required: true
      - name: password
        in: formData
        type: string
        required: true
    responses:
      200:
        description: User successfully logged in.
      400:
        description: User login failed.
    """
    try:
        username = request.form.get("username")
        password = request.form.get("password")

        user = authenticate(username, password)
        if not user:
            raise Exception("User not found!")

        resp = jsonify({"message": "User authenticated"})
        resp.status_code = 200

        access_token = jwt.jwt_encode_callback(user)

        # add token to response headers - so SwaggerUI can use it
        resp.headers.extend({'jwt-token': access_token})

    except Exception as e:
        resp = jsonify({"message": "Bad username and/or password"})
        resp.status_code = 401

    return resp


@app.route("/protected", methods=["GET"])
@jwt_required()
def protected():
    """
    Protected content method.
    ---
    description: Protected content method. Can not be seen without valid token.
    responses:
      200:
        description: User successfully accessed the content.
    """
    curr_proxy = '72.179.25.215:2030:lawrank:01lawrank'
    curr_proxy = curr_proxy.split(':')
    if len(curr_proxy) == 4:
        proxy = curr_proxy[0]
        port = curr_proxy[1]
        proxyU = curr_proxy[2]
        proxyP = curr_proxy[3]
    else:
        proxy = curr_proxy[0]
        port = curr_proxy[1]
    options = Options()
    options.binary_location = browser_path
    options.add_argument("--no-sandbox")
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
        # options.add_argument("--disable-dev-shm-usage")
        # options.add_argument("--remote-debugging-port=9222")
    if len(curr_proxy) == 4:
        wireoptions = {
            'proxy': {
                'http': f'http://{proxyU}:{proxyP}@{proxy}:{port}',
                'https': f'https://{proxyU}:{proxyP}@{proxy}:{port}',
                'no_proxy': 'localhost,127.0.0.1'

                }
        }
    else:
        wireoptions = {
            'proxy': {
                'http': f'http://{proxy}:{port}',
                'https': f'https://{proxy}:{port}',
                'no_proxy': 'localhost,127.0.0.1'
                }
        }
    options.add_experimental_option('prefs', {
        'credentials_enable_service': False,
        'profile': {
            'password_manager_enabled': False,
            'default_content_setting_values.notifications': 2,
            'profile.default_content_setting_values.media_stream_mic': 2,
            'profile.default_content_setting_values.geolocation': 2
            }
        })
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-blink-features=AutomationControlled")
    driver = webdriver.Chrome(executable_path=driver_path,
                                    options=options, seleniumwire_options=wireoptions)
    do = Predefined(driver)
    driver.get('https://telegra.ph/')
    do.waitforelementdisplay('//div[@class="ql-editor"]/h1', 20)
    do.move_mouse_click('//div[@class="ql-editor"]/h1', '//div[@class="ql-editor"]/h1')
    time.sleep(1)
    do.type_human_delay('//div[@class="ql-editor"]/h1', Title, 0.1, 0.3)
    time.sleep(1)
    do.move_mouse_click('//div[@class="ql-editor"]/p', '//div[@class="ql-editor"]/p')
    time.sleep(1)
    do.ChangeAttribute('//div[@class="ql-editor"]/p', 'innerHTML', Description)
    time.sleep(1)
    do.scroll_to_element('//button[@id="_publish_button"]')
    time.sleep(1)
    do.move_mouse('//button[@id="_publish_button"]')
    time.sleep(1)
    do.doclick('//button[@id="_publish_button"]')
    do.waitforelementdisplay('//button[@id="_edit_button"]', 20)
    if do.element_display('//button[@id="_edit_button"]'):
        link = driver.current_url
        return link, 200
    driver.close()
    driver.quit()
    # resp = jsonify({"protected": "{} - you saw me!".format(current_identity)})
    # resp.status_code = 200
    # print("You have accessedd the protected page")
    # return resp


if __name__ == '__main__':
    app.run()